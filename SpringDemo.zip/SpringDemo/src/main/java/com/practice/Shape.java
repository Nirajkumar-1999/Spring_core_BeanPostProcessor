package com.practice;

public interface Shape {
	
	public void draw();
		
	
}
